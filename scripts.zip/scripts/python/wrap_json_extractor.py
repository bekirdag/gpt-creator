#!/usr/bin/env python3
"""Hardened JSON extraction helper for Codex outputs."""

